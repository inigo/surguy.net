Parse XML examples from the OOXML specification, and report on well-formedness and validation errors.
I have run this on Java 6 - it may well work on Java 5, but definitely won't work on anything earlier.

To prepare XML for this to run against:
 * Start with the OOXML specification document in OOXML form (from ECMA)</li>
 * Convert headings to the form h1, h2, h3, etc. with fixHeadings.xsl</li>
 * Extract code examples with extractCode.xsl (the two stylesheets could be combined, but
   I haven't yet taken the time. The reason they're separate in the first place is because
   initially I was attempting to do the heading count in XSLT, before I gave up and
   used Java instead)

To prepare the schema:
 * Fix the bug in the schema imports described at http://www.xmlopen.org/ooxml-wiki/index.php/Schema_Annexes</li>
 * Download the W3C's schema for the XML namespace, and refer to it in the schemas</li>
 * Move as many element definitions as is practical to top-level in the schema - convertElementsToRef.xsl
     does most of what's needed, and with a few tweaks could do everything</li>

Then run via the main method in OOXMLValidator.

At the moment, the code is set up to work for WordProcessingML. I haven't done the data
extraction and schema changes to work with any of the other parts of the code.

Please contact me with comments at inigo.surguy@gmail.com

----
The Java and XSLT code is copyright (C) 2007 Inigo Surguy. The schemas
and code examples are copyright Ecma 2006.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
