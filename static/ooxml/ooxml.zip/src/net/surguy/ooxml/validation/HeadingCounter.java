package net.surguy.ooxml.validation;
//    OOXML example validator
//    Copyright (C) 2007 Inigo Surguy
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

/**
 * Keep track of heading depth and numbering, based on a flat h1, h2, h3, etc. structure. 
 * <p/>
 * @author Inigo.Surguy
 * @created 28-May-2007 13:50:12
*/
class HeadingCounter {
    private int[] headingCount = new int[]{0, 0, 0, 0, 0, 0, 0};
    private int lastHeading = 0;
    private int exampleNumber = 0;

    void adjustHeading(String name) {
        int headingDepth = Integer.parseInt(name.substring(1));
        if (headingDepth > lastHeading) {
            headingCount[headingDepth - 1] = 1;
        } else if (headingDepth == lastHeading) {
            headingCount[headingDepth - 1]++;
        } else {
            headingCount[headingDepth - 1]++;
            clearHeadings(headingDepth);
        }
        lastHeading = headingDepth;
        exampleNumber = 0;
    }

    private void clearHeadings(int level) {
        for (int i = level; i < headingCount.length; i++) {
            headingCount[i] = 0;
        }
    }

    String getHeadingDepth() {
        StringBuilder sb = new StringBuilder();
        String separator = "";
        for (Integer integer : headingCount) {
            if (integer != 0) {
                sb.append(separator).append(integer);
            } else {
                break;
            }
            separator = ".";
        }
        sb.append(" example ").append(exampleNumber);
        return sb.toString();
    }

    public void incrementExampleNumber() {
        exampleNumber++;
    }
}
