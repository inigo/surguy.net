package net.surguy.ooxml.validation;
//    OOXML example validator
//    Copyright (C) 2007 Inigo Surguy
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.


import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.DocumentSource;
import org.dom4j.io.SAXReader;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import java.io.*;
import java.util.*;

/**
 * Parse XML examples from the OOXML specification, and report on well-formedness and validation errors.
 * I have run this on Java 6 - it may well work on Java 5, but definitely won't work on anything earlier.
 * <p>
 * To prepare XML for this to run against:
 * <ul>
 * <li>Start with the OOXML specification document in OOXML form (from ECMA)</li>
 * <li>Convert headings to the form h1, h2, h3, etc. with fixHeadings.xsl</li>
 * <li>Extract code examples with extractCode.xsl (the two stylesheets could be combined, but
 * I haven't yet taken the time. The reason they're separate in the first place is because
 * initially I was attempting to do the heading count in XSLT, before I gave up and
 * used Java instead)</li>
 *
 * </ul>
 * To prepare the schema:
 * <ul>
 * <li>Fix the bug in the schema imports described at http://www.xmlopen.org/ooxml-wiki/index.php/Schema_Annexes</li>
 * <li>Download the W3C's schema for the XML namespace, and refer to it in the schemas</li>
 * <li>Move as many element definitions as is practical to top-level in the schema - convertElementsToRef.xsl
 *      does most of what's needed, and with a few tweaks could do everything</li>
 * </ul>
 *
 * @author inigo.surguy
 */
public class OOXMLValidator {
    private final Logger log = Logger.getLogger(OOXMLValidator.class);

    private Document xml;
    private HeadingCounter headings;
    private final Schema schema;

    private int wasValid = 0;
    private int wasInvalid = 0;
    private int wasMalformed = 0;
    private int notTopLevel = 0;
    private int total = 0;

    private Map<String, Integer> notValidated = new HashMap<String, Integer>();

    public OOXMLValidator(String xmlFilename) throws FileNotFoundException, DocumentException, SAXException {
        File xmlFile = new File(xmlFilename);
        if (!xmlFile.exists()) {
            throw new IllegalArgumentException("Cannot find " + xmlFile.getAbsolutePath());
        }
        xml = new SAXReader().read(new FileInputStream(xmlFile));
        headings = new HeadingCounter();

        SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        schema = factory.newSchema(new File("schema/wml.xsd"));
    }


    private void invoke() throws IOException {
        //noinspection unchecked
        List<Element> elements = xml.getRootElement().elements();
        StringBuffer codeSoFar = new StringBuffer();
        String lastElementName = "";
        for (Element element : elements) {
            String ename = element.getName();

            if (ename.equals("code")) {
                codeSoFar.append(" ").append(element.getText()).append(" ");
            } else if (lastElementName.equals("code")) {
                headings.incrementExampleNumber();
                processCode(codeSoFar.toString());
                codeSoFar = new StringBuffer();
            }

            if (ename.startsWith("h")) {
                headings.adjustHeading(ename);
            }
            lastElementName = ename;
        }
        log.info("Complete - valid " + wasValid + ", invalid " + wasInvalid + ", malformed " + wasMalformed + 
                ", ignored as not top level "+notTopLevel+" out of total " + total);
        log.info("Elements not validated (not top level in schema): " + notValidated);
    }

    private void processCode(String codeText) throws IOException {
        String namespacedCodeText = preSanitizeCode(codeText);
        if (namespacedCodeText == null) {
            return;
        }

        List<Document> documents = new ArrayList<Document>();
        total++;
        try {
            Document code = new SAXReader().read(new StringReader(namespacedCodeText));
            documents.add(code);
        } catch (DocumentException e) {
            documents = tidyAndReparse(namespacedCodeText);
            if (documents.isEmpty()) {
                log.warn(headings.getHeadingDepth() + "\tCode is not well-formed XML : " + e + "\t" + codeText);
            }
        } catch (Exception e) {
            log.warn(headings.getHeadingDepth() + "\tSome other XML error : " + e + "\t" + codeText);
        }
        for (Document document : documents) {
            validate(document, codeText);
        }
    }

    private String preSanitizeCode(String codeText) {
        try {
            // Force in the namespace declarations that are not present in the spec
            int firstBracket = codeText.indexOf(">", codeText.indexOf("?>") + 2);
            if (codeText.charAt(firstBracket - 1) == '/') firstBracket--;
            codeText = codeText.substring(0, firstBracket) + Constants.namespaces + codeText.substring(firstBracket);

            // Remove ellipsis - this appears in many examples
            codeText = codeText.replaceAll("\"�\"", " ");
            codeText = codeText.replaceAll("�", " ");
            codeText = codeText.replaceAll("\"\\.\\.\\.\"", " ");
            codeText = codeText.replaceAll("\\.\\.\\.", " ");

            // Trim whitespace between angled brackets
            codeText = codeText.replaceAll(">\\s+", ">");
            codeText = codeText.replaceAll("\\s+<", "<");

            return codeText;
        } catch (Exception e) {
            if (codeText.trim().startsWith("<") && codeText.trim().endsWith(">")) {
                log.warn(headings.getHeadingDepth()+" Code is not well-formed - angle brackets are misplaced\t"+codeText);
            }
            return null;
        }
    }

    private List<Document> tidyAndReparse(String codeText) {
        List<Document> documents = new ArrayList<Document>();

        // Replace curly quotes and then try parsing again
        codeText = codeText.replaceAll("�", "\"");
        codeText = codeText.replaceAll("�", "\"");
        try {
            Document code = new SAXReader().read(new StringReader(codeText));
            log.warn(headings.getHeadingDepth()+ "\tCode is using curly quotes: continuing\t"+codeText);
            wasMalformed++;
            documents.add(code);
            return documents;
        } catch (DocumentException e) {
            // Expected
        }

        // If parsing fails, add a root element, reparse, and then return a List<Document>, because
        // often subsequent examples are all separate elements
        try {
            String newCodeText = "<root "+Constants.namespaces+ " >" + codeText + "</root>";
            Document code = new SAXReader().read(new StringReader(newCodeText));
            //noinspection unchecked
            for (Element e : (Iterable<? extends Element>) code.getRootElement().elements()) {
                Document document = DocumentFactory.getInstance().createDocument((Element) e.detach());
                documents.add(document);
            }
            return documents;
        } catch (DocumentException e) {
            // Expected
        }

        // @todo Should try harder to fix up malformed XML  - but neither JTidy or TagSoup work properly for XML (just HTML)
        return documents;
    }

    private void validate(Document code, String codeText) throws IOException {
        try {
            Validator validator = schema.newValidator();
            validator.validate(new DocumentSource(code));
            wasValid++;
        } catch (SAXException e) {
            reportValidationError(codeText, e.getMessage());
        }
    }

    private void reportValidationError(String codeText, String exceptionMessage) {
        if (exceptionMessage.contains("Cannot find the declaration of element")) {
            String elementName = exceptionMessage.replaceAll(".*?declaration of element '(.*)'.*", "$1");
            log.info(headings.getHeadingDepth() + "\tDidn't try to validate because " + elementName + " isn't top-level in schema\t" + codeText);
            notTopLevel++;
            addNotValidatedCount(elementName);
        } else {
            log.error(headings.getHeadingDepth() + "\tFailed to validate " + exceptionMessage + " \t" + codeText);
            wasInvalid++;
        }
    }

    private void addNotValidatedCount(String elementName) {
        if (notValidated.containsKey(elementName)) {
            notValidated.put(elementName,  notValidated.get(elementName)+1 );
        } else {
            notValidated.put(elementName,  1 );
        }
    }


    public static void main(String[] args) throws Exception {
        OOXMLValidator validator = new OOXMLValidator("data/word_ref.xml");
        validator.invoke();
    }

}
