package net.surguy.ooxml.validation;
//    OOXML example validator
//    Copyright (C) 2007 Inigo Surguy
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

/**
 * The namespace URIs and prefixes used in OOXML examples.
 *
 * @author Inigo.Surguy
 * <p/>
 * @created 28-May-2007 13:51:35
 */
class Constants {
    // None of the WordML examples have namespaces attached - it's necessary to add them
    // manually. It's necessary to do this via string manipulation because the XML isn't well-formed.
    static String namespaces =
            // Copied from WordML declarations
                    "    xmlns:ve=\"http://schemas.openxmlformats.org/markup-compatibility/2006\"" +
                    "    xmlns:o=\"urn:schemas-microsoft-com:office:office\"" +
                    "    xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"" +
                    "    xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\"" +
                    "    xmlns:v=\"urn:schemas-microsoft-com:vml\"" +
                    "    xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\"" +
                    "    xmlns:w10=\"urn:schemas-microsoft-com:office:word\"" +
                    "    xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"" +
                    "    xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\"" +
                    "    xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\"" +
                    "    xmlns:dcmitype=\"http://purl.org/dc/dcmitype/\"" +
                    "    xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"" +
            // Looked up in spec - not obvious
                    "    xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\"" +
                    "    xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\"" +
                    "    xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"" +
                    "    xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\"" +
                    "    xmlns:cdr=\"http://schemas.openxmlformats.org/drawingml/2006/chartDrawing\"" +

                    // A guess...
                    "    xmlns:s=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"" +

                    // No idea!
                    "    xmlns:x=\"temp\"" +
                    "    xmlns:b=\"temp\"" +
                    "    xmlns:c=\"temp\"" +
                    "    xmlns:oxsd=\"temp\"" +



                    "    xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\" ";
}
