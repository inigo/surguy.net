package inigo;

public interface StoresContracts {
    String getValue();
    void setValue(String value);
}
